=== Grid Gallery - Photo Image Grid Gallery ===
Contributors: awordpresslife
Donate link: https://paypal.me/awplife
Tags: photo gallery, image gallery, wordpress gallery plugin, portfolio gallery, grid gallery
Requires at least: 3.8
Tested up to: 6.3.2
Stable tag: 1.3.8
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Grid Gallery - Awesome plugin for your Gallery, plugin is allow users to view larger images, designer slide shows, Easing Effects and responsive grid gallery columns layout
Image, Photo Slider Grid, Google Type Grid, Google Type Gallrey

== Description ==

= Grid Gallery - Image, Photo Slider Grid, Google Type Grid =

There are dozens of "Grid Gallery" out there, but the problem is that they always work the same!

Grid Gallery uses a brand new algorithm to make much more interesting image grids, how does it work?

The main concept is very simple: it doesn’t have any lightbox, because in grid gallery images open without lightbox like a slider, it means it’s working like a slider but it looks like a gallery.

You can create photo gallery with classical square grid layout.

Grid Gallery is the best for any site who showing their images like a gallery and slider combine.

Grid gallery is based on Irresistible CSS & JS, So it is very amazing, responsive and easy to use.

The Grid Gallery is fully responsive and it adapts to the browser using a nice and smooth animation, even on mobile devices because it can use the hardware acceleration taking advantage of CSS3 properties.

You can create unlimited photo galleries in seconds with grid gallery plugin.

Gallery plugin with easy interface and very attractive hover animation effects. 

Gallery have simple clean interface, quick and simple image gallery settings configuration. 

Gallery support advanced eye catching hover text animation, It fully responsive it is support all mobile touch screen devices in photo gallery. 

Grid Gallery - an awesome plugin for your blog, This plugin is allow users to view larger images, designer slide shows, Easing Effects and responsive photo gallery columns layout

https://www.youtube.com/watch?v=GusIaoInRJQ

**Upgrade To Premium Plugin - <a href="https://awplife.com/wordpress-plugins/grid-gallery-premium/">Click Here</a>**

**Check Premium Plugin Demo - <a href="https://awplife.com/demo/grid-gallery-premium/">Click Here</a>**

= GRID GALLERY PRO FEATURES AND DEMO =

> #### **Demo Pro Version**

> * [Grid Gallery Premium](https://awplife.com/demo/grid-gallery-premium/ "Grid Gallery Premium")
> * [Customize Border Settings](https://awplife.com/demo/grid-gallery-premium/customize-border-settings/ "Customize Border Settings")
> * [Thumbnail Settings](https://awplife.com/demo/grid-gallery-premium/thumbnail-setting/ "Thumbnail Settings")
> * [Image Hover Effects](https://awplife.com/demo/grid-gallery-premium/image-hover-effects/ "Image Hover Effects")
> * [Animation Speed On Image Open](https://awplife.com/demo/grid-gallery-premium/animation-speed-on-image-open/ "Animation Speed On Image Open")
> * [Easing Effect On Image Open](https://awplife.com/demo/grid-gallery-premium/easing-effect/ "Easing Effect On Image Open")
> * [Spacing Settings](http://awplife.com/demo/grid-gallery-premium/spacing-settings/ "Spacing Settings")
> * [Link Settings](https://awplife.com/demo/grid-gallery-premium/link-settings/ "Link Settings")
> * [Title And Description On Image](https://awplife.com/demo/grid-gallery-premium/title-and-description-on-image-preview/ "Title And Description On Image")
> * [Title And Description On Thumbnails](https://awplife.com/demo/grid-gallery-premium/title-and-description-on-thumbnails/ "Title And Description On Thumbnails")
> * [Column Layout](https://awplife.com/demo/grid-gallery-premium/column-layout/ "Column Layout")
> * [Admin Demo](https://awplife.com/demo/grid-gallery-premium-admin-demo/ "Admin Demo")
> * [Buy Grid Gallery Premium](https://awplife.com/account/signup/grid-gallery-premium "Buy Grid Gallery Premium")

**Get Premium Version With More Features**

* Responsive Gallery
* Link Gallery
* Description Gallery
* Image Uploader
* Image Title
* Short codes
* Multiple Column Layouts
* Animation Easing Effect
* Animation Speed  
* Hover Effects
* Transition Effects
* Auto Scroll
* Navigation Buttons Position
* Title On Image Preview
* Description On Image Preview
* Title Settings
* Color Picker
* Title & Description Settings
* Thumbnail 
* Thumbnail Border Settings
* Hide Image Spacing
* Custom CSS
* Photo Gallery in Post
* Photo Gallery in Page
* SEO Friendly Gallery
* Thumbnail Size & Quality Setting
* Navigation Error in Light Box Preview
* Gallery Images Order Setting Like Ascending, Descending & Shuffle
* Simple & User-Friendly Custom Plugin Dashboard
* Create Unlimited Galleries With Unlimited Images
* Easy To Implement Anywhere Into WordPress
* Easily Customization
* Fast, Friendly & Quality Support

== Installation ==

Install New Grid Gallery either via the WordPress.org plugin directory, or by uploading the files to your server.

After activating Grid Gallery plugin, go to plugin menu.

Create new gallery, configure settings and save.

Copy gallery shortcode and publish on page / post.

That's it. You're ready to go!

== Frequently Asked Questions ==

Have any queries?

Please post your question on plguin support forum

https://wordpress.org/support/plugin/grid-gallery/

= Recommended Plugins =

The following are other recommended plugins by the author:

* [Portfolio Filter Gallery](https://wordpress.org/plugins/portfolio-filter-gallery/ "Best Portfolio Filter Gallery") - The Gallery Plugin to create awesome Portfolio Filter Gallery Plugin in minutes. 

The following are other recommended plugins by the author:

* [Portfolio Filter Gallery](https://wordpress.org/plugins/blog-filter/ "Best Blog Filter Gallery") - The Gallery create Blog Filter Gallery in minutes. 

**Buy Premium Plugin - <a href="https://awplife.com/wordpress-plugins/blog-filter-premium/">Click Here</a>**

* [Media Slider](https://wordpress.org/plugins/media-slider/ "Best Media Slider") - The Media Slider Plugin to create Media / Video Slider Gallery Plugin in minutes. 

**Buy Premium Plugin - <a href="https://awplife.com/wordpress-plugins/media-slider-premium/">Click Here</a>**

* [Best Weather Effect Plugin](https://wordpress.org/plugins/weather-effect/ "Best Weather Effect Plugin") - Very Simple And Easy To Design Your Sites With Multiple Effects.

**Buy Premium Plugin - <a href="https://awplife.com/wordpress-plugins/weather-effect-premium/">Click Here</a>**

* [Best Gallery Plugin](https://wordpress.org/plugins/new-grid-gallery/ "Bes Galley Plugin") - Easy Gallery Widget - Displaying your image in Page & Post widget/sidebar area with very easy.Allows you to customize it to looking exactly what you want.

**Buy Premium Plugin - <a href="https://awplife.com/wordpress-plugins/grid-gallery-premium/">Click Here</a>**

* [Image Gallery Plugin](https://wordpress.org/plugins/new-image-gallery/ "Image Gallery Plugin") - Gallery Lightbox - Displays all gallery images into the lightbox slider in just a few seconds.

**Buy Premium Plugin - <a href="https://awplife.com/wordpress-plugins/image-gallery-premium/">Click Here</a>**

* [Photo Gallery Plugin](https://wordpress.org/plugins/new-photo-gallery/ "Image Gallery Plugin") - Displays all  Photo Gallery, Video Gallery, Link Gallery, Map Gallery into Wordpress in just a few seconds.

**Buy Premium Plugin - <a href="https://awplife.com/wordpress-plugins/photo-gallery-premium/">Click Here</a>**

* [Slider Plugin](https://wordpress.org/plugins/responsive-slider-gallery/ "Slider Plugin") - Fully Responsive Slider Gallery For Wordpress ,You can Show Slider Into Page/Post & Widget/Sidebar By Generate Shortcode.

**Buy Premium Plugin - <a href="https://awplife.com/wordpress-plugins/responsive-slider-gallery-premium/">Click Here</a>**

* [Contact Form](https://wordpress.org/plugins/new-contact-form-widget/ "Contact Form Plugin") - Contact Form Widget Shortcode Plugin For WordPress.

**Buy Premium Plugin - <a href="https://awplife.com/wordpress-plugins/contact-form-premium/">Click Here</a>**

* [Social Media Plugin](https://wordpress.org/plugins/new-social-media-widget/ "Social Media") - Display your Social Media Plugin into Widget/Sidebar in WordPress site with very easily.

**Buy Premium Plugin - <a href="https://awplife.com/wordpress-plugins/social-media-widget-premium//">Click Here</a>**

* [Best Responsive Slider Plugin](https://wordpress.org/plugins/slider-responsive-slideshow/ "Responsive Slider Plugin") - Fully Responsive Light Weight Easy Powerful WordPress Slider Slideshow Plugin.

**Buy Premium Plugin - <a href="https://awplife.com/wordpress-plugins/slider-responsive-slideshow-premium//">Click Here</a>**

* [Video Gallery Plugin](https://wordpress.org/plugins/new-video-gallery/ "Best Video Gallery Plugin") - The Best Responsive video gallery For Wordpress.

**Buy Premium Plugin - <a href="https://awplife.com/wordpress-plugins/video-gallery-premium/">Click Here</a>**

* [Facebook Like Share Follow Button](https://wordpress.org/plugins/new-facebook-like-share-follow-button/ "Facebook Like Share Follow Button") - Display your Facebook Like Share Follow Button Plugin into Page/Post & Widget/Sidebar in WordPress sites with very easily.
 
* [Google Plus Badge](https://wordpress.org/plugins/new-google-plus-badge/ "Google Plus Badge") - Google+ Badge & Profile Widget For Show Into Widget & sidebar

* [Facebook Like Box Plugin](https://wordpress.org/plugins/facebook-likebox-widget-and-shortcode/ "Facebook Likebox Plugin") - Facebook Light Box Plugin For Wordpress 
 

== Screenshots ==

1. Grid Gallery Plugin
2. Preview
3. Responsive Gallery
4. Without Spacing
5. With Spacing
6. Without Title 
7. With Title
8. Navigation Buttons Position Right Side  On Image Preview
9. Navigation Buttons Position Left Side  On Image Preview
10. Image Preview 
11. Shortcode Settings
12. Tools option
13. Settings Page

== Changelog ==

= 1.3.8 =
* Enhancements: tested for WordPress 6.3.2

= 1.3.7 =
* Enhancements: tested for WordPress 6.3.1

= 1.3.6 =
* Enhancements: tested for WordPress 6.2.2

= 1.3.5 =
* Enhancements: tested for WordPress 6.2.1

= 1.3.4 =
* Enhancements: tested for WordPress 6.1.1

= 1.3.3 =
* Enhancements: tested for WordPress 6.0.3

= 1.3.2 =
* wordpress security issues fixed

= 1.3.1 =
* Enhancements: tested for WordPress 6.0.1

= 1.3.0 =
* Enhancements: tested for WordPress 6.0

= 1.2.9 =
* Enhancements: tested for WordPress 5.9.3

= 1.2.8 =
* Enhancements: tested for WordPress 5.9

= 1.2.7 =
* Enhancements: tested for WordPress 5.8.1
* wordpress security issues fixed

= 1.2.6 =
* Enhancements: tested for WordPress 5.8.1

= 1.2.5 =
*  XSS [ Cross Site Scripting] Security issues fixed.

= 1.2.4 =

* Fixed Security issues.
* Bug: Miner Issue Fixed.

= 1.2.3 =

* Bug: Miner Issue Fixed.

= 1.2.2 =

* Enhancements: tested for WordPress 5.7.2

= 1.2.1 =

* Enhancements: tested for WordPress 5.7.1

= 1.2.0 =

* Enhancements: tested for WordPress 5.7

= 1.1.10 =

* Enhancements: tested for WordPress 5.6.2

= 1.1.9 =

* Enhancements: tested for WordPress 5.6
* Bug: Bootstrap.js Issue Fixed.

= 1.1.8 =

* Enhancements: tested for WordPress 5.5.3
* Bug: Miner Issue Fixed.

= 1.1.7 =

* Enhancements: tested for WordPress 5.5.3

= 1.1.6 =

* Enhancements: tested for WordPress 5.5.1
* Bug: Miner Issue Fixed.

= 1.1.5 =

* Enhancements: tested for WordPress 5.5
* Bug: Miner Issue Fixed.

= 1.1.4 =

* Enhancements: tested for WordPress 5.4.2

= 1.1.3 =

* Enhancements: tested for WordPress 5.4.1
* Bug: Fixed

= 1.1.2 =

* Enhancements: tested for WordPress 5.4.1

= 1.1.1 =

* Enhancements: tested for WordPress 5.3.2

= 1.1.0 =

* Enhancements: tested for WordPress 5.3.2

= 1.0.10 =

* Enhancements: tested for WordPress 5.2.3

= 1.0.9 =

* Enhancements: tested for WordPress 5.2.3

= 1.0.8 =

* Enhancements: tested for WordPress 5.2.2
* Bug Fix: Fixed


= 1.0.7 =

* Enhancements: tested for WordPress 5.2.2
* Bug Fix: Fixed
* Additional changes: None.

= 1.0.6 =

* Enhancements: tested for WordPress 5.2.2
* Bug Fix: Fixed
* Additional changes: None.

= 1.0.5 =

* Enhancements: tested for WordPress 5.2.1
* Bug Fix: Fixed
* Additional changes: None.

= 1.0.4 =

* Enhancements: tested for WordPress 5.2.1
* Bug Fix: Fixed
* Additional changes: None.

= 1.0.3 =

* Enhancements: tested for WordPress 5.1.1
* Bug Fix: Fixed
* Additional changes: None.

= 1.0.2 =

* Enhancements: tested for WordPress 5.1.1
* Bug Fix: Fixed
* Additional changes: None.

= 1.0.1 =

* Enhancements: tested for WordPress 5.0.3
* Bug Fix: Fixed
* Additional changes: None.

= 1.0.0 =

* Enhancements: tested for WordPress 5.0.3
* Bug Fix: Fixed
* Additional changes: None.

= 0.5.0 =

* Enhancements: tested for WordPress 5.0.3
* Bug Fix: Fixed
* Additional changes: None.

= 0.4.9 =

* Enhancements: tested for WordPress 5.0.2
* Bug Fix: Fixed
* Additional changes: None.

= 0.4.8 =

* Enhancements: tested for WordPress 5.0.2
* Bug Fix: Yes
* Additional changes: None.

= 0.4.7 =

* Enhancements: tested for WordPress 5.0.1
* Bug Fix: Yes
* Additional changes: None.

= 0.4.6 =

* Enhancements: None
* Bug Fix: Yes
* Additional changes: Custome shortcode copy.

= 0.4.5 =

* Enhancements: None
* Bug Fix: None
* Additional changes: Site Links Changed

= 0.4.4 =

* Enhancements: tested for WordPress 4.9.8
* Bug Fix: Yes
* Additional changes: No

= 0.4.3 =

* Enhancements: tested for WordPress 4.9.8
* Bug Fix: None
* Additional changes: yes, Added Hindi Translation file. 

= 0.4.2 =

* Enhancements: tested for WordPress 4.9
* Bug Fix: None
* Additional changes: yes, Added Featured Page. 

= 0.4.1 =

* Enhancements: tested for WordPress 4.9
* Bug Fix: None
* Additional changes: yes, Added theme menu. 


Feature Enhancements: Version 0.4.0
* Enhancements: None
* Bug Fix: Yes, blog page bug Fixed.
* Additional changes: None

Feature Enhancements: Version 0.3.9
* Enhancements: None
* Bug Fix: Yes, blog page bug Fixed.
* Additional changes: None

Feature Enhancements: Version 0.3.8
* Enhancements: None
* Bug Fix: Fixed
* Additional changes: None

Feature Enhancements: Version 0.3.7
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.3.6
* Enhancements: tested upto new version 4.8.1
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.3.5
* Enhancements: tested upto new version 4.8
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.3.4
* Enhancements: tested upto new version 4.8
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.3.3
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.3.2
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.3.1
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.3.0
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.2.9
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.2.8
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.2.7
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.2.6
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.2.5
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.2.4
* Enhancements: Compatible For New Version
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.2.3
* Enhancements: Compatible For New Version
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.2.2
* Enhancements: Compatible For New Version
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.2.1
* Enhancements: Compatible For New Version
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.1.9
* Enhancements: Compatible For New Version
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.1.8
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.1.7
* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.1.6

* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.1.5

* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.1.4

* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.1.3

* Enhancements: None
* Bug Fix: None
* Additional changes: Yes, added 2 new settings

Feature Enhancements: Version 0.1.2

* Enhancements: Yes, upgraded for WordPress 4.7
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.1.1.1

* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.1.1

* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.1.0

* Enhancements: None
* Bug Fix: None
* Additional changes: Yes, user interface layout change

Feature Enhancements: Version 0.0.9

* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.0.8

* Enhancements: None
* Bug Fix: yes, navigation settings
* Additional changes: None

Feature Enhancements: Version 0.0.7

* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.0.6

* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.0.5

* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.0.4

* Enhancements: None
* Bug Fix: alignment fix, title update fix,  
* Additional changes: None

Feature Enhancements: Version 0.0.3

* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.0.2

* Enhancements: None
* Bug Fix: None
* Additional changes: None

Feature Enhancements: Version 0.0.1

* Enhancements: None
* Bug Fix: None
* Additional changes: None

== Upgrade Notice ==
This is an initial release. Start with version 0.1. and share your feedback <a href="https://wordpress.org/support/view/plugin-reviews/grid-gallery//">here</a>.